/*  Inicializa Firebase con la
 * configuración del proyecto.
 * Revisa la configuración en tu
 * servidor de Firebase y cópiala
 * aquí sustituyendo los
 * asteriscos. Los campos deben
 * quedar igual que en tu
 * servidor. */
// @ts-ignore
firebase.initializeApp({
    apiKey: "AIzaSyDzZxk913MUi3ESjLwNK14W0t1c6HgUOWE",
    authDomain: "bdfalumnox.firebaseapp.com",
    projectId: "bdfalumnox",
    storageBucket: "bdfalumnox.appspot.com",
    messagingSenderId: "1002536188546",
    appId: "1:1002536188546:web:cfa9fb33aec119e7fc529b",
    measurementId: "G-5HHSLWQ24J"
});
